def my_util_function():
    # Some logic here
    return "world"
